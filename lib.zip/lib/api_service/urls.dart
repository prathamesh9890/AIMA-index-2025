

import 'package:tms_app/api_service/prefs/PreferencesKey.dart';
import 'package:tms_app/api_service/prefs/app_preference.dart';

String baseUrl = 'https://aimaindex.techmetworks.com/api/';
String stalLLogin = '${baseUrl}stallLogin';
String scanUser = '${baseUrl}scanUser';

String stallUserList = '${baseUrl}StallUserList';



// const String infoTipsEndpoint = "admin/api-information-title-list";
// const String infoDetailEndpoint = "admin/api-sub-information-list";







