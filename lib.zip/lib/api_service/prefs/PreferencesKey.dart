class PreferencesKey {
 static String token = "token";
  static String stall_id = "stall_id";
  static String stall_no = "stall_no";
  static String stall_name = "stall_name";
  static String business = "business";
  static String stall_user_name = "stall_user_name";
  static String mobile = "mobile";
  static String email = "email";
  static String website = "website";
  static String created_at = "created_at";
  static String updated_at = "updated_at";

}
